//
//  ViewController.swift
//  FTC-Scouting
//
//  Created by Koen Flynn on 7/20/20.
//  Copyright © 2020 Cheese. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var textViews: UITextField!
    
    override func viewDidLoad(){
        super.viewDidLoad()
    }
    
    /*
    touchesBegan(  touches: Set<UITouch>, with event: UIEvent?){
               self.view.endEditing(true)
        }
     */
    /*
         func textView(textView: UITextField, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
               
               if text == "\n" {
                   
                   textViews.resignFirstResponder()
                   return false
                   
               }
               
               return true
        }
   */
        
    }

