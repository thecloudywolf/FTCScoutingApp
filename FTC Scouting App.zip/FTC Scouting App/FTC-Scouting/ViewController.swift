//
//  ViewController.swift
//  FTC-Scouting
//
//  Created by Koen Flynn on 7/20/20.
//  Copyright © 2020 Cheese. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var textViews: UITextField!
    
    override func viewDidLoad(){
        super.viewDidLoad()
    }
}
